package bean;

import java.sql.Blob;

public class Product {
	private String productname,featured,flashsale,category,description,stock,unit;
	private int price,id;
	private Blob productimg;
	
	public Product() {
		
	}

	public Product(String productname, String featured, String flashsale, String category, String description,
			String stock, String unit, int price, int id, Blob productimg) {
		
		this.productname = productname;
		this.featured = featured;
		this.flashsale = flashsale;
		this.category = category;
		this.description = description;
		this.stock = stock;
		this.unit = unit;
		this.price = price;
		this.id = id;
		this.productimg = productimg;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public String getFeatured() {
		return featured;
	}

	public void setFeatured(String featured) {
		this.featured = featured;
	}

	public String getFlashsale() {
		return flashsale;
	}

	public void setFlashsale(String flashsale) {
		this.flashsale = flashsale;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Blob getProductimg() {
		return productimg;
	}

	public void setProductimg(Blob productimg) {
		this.productimg = productimg;
	}

	@Override
	public String toString() {
		return "Product [productname=" + productname + ", featured=" + featured + ", flashsale=" + flashsale
				+ ", category=" + category + ", description=" + description + ", stock=" + stock + ", unit=" + unit
				+ ", price=" + price + ", id=" + id + ", productimg=" + productimg + "]";
	}

	
}