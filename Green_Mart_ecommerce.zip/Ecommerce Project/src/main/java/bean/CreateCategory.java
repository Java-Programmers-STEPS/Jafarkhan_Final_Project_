package bean;

public class CreateCategory {
	
	private String createcategory;
	private int id;
	public String getCreatecategory() {
		return createcategory;
	}
	public void setCreatecategory(String createcategory) {
		this.createcategory = createcategory;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}



}
