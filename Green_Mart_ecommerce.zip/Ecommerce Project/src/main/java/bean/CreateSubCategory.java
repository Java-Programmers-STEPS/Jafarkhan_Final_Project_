package bean;

public class CreateSubCategory {
	private String category,createsubcategory;
	private int id;
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getCreatesubcategory() {
		return createsubcategory;
	}
	public void setCreatesubcategory(String createsubcategory) {
		this.createsubcategory = createsubcategory;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
