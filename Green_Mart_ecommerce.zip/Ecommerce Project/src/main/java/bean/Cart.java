package bean;

public class Cart extends Product{
	private int quantity;
	

	

	public Cart() {
	}


	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public void setPrice(double d) {
		// TODO Auto-generated method stub
		
	}
	
}