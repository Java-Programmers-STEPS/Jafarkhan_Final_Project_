package dao;

import java.sql.*;
import java.util.*;

//import cn.techtutorial.model.Cart;
//import cn.techtutorial.model.Product;
import bean.*;

public class ProductDao {
	private Connection con;

	private String query;
    private PreparedStatement pst;
    private ResultSet rs;
    

	public ProductDao(Connection con) {
		super();
		this.con = con;
	}
	
	
	public List<bean.Product> getAllProducts() {
        List<bean.Product> book = new ArrayList<>();
        try {

            query = "select * from products "
            		+ "";
            pst = this.con.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()) {
            	bean.Product row = new bean.Product();
                row.setId(rs.getInt("id"));
                row.setProductname(rs.getString("productname"));
                row.setFeatured(rs.getString("featured"));
                row.setFlashsale(rs.getString("flashsale"));
                row.setCategory(rs.getString("category"));
                row.setDescription(rs.getString("description"));
                row.setStock(rs.getString("stock"));
                row.setUnit(rs.getString("unit"));
                row.setPrice(rs.getInt("price"));
                row.setProductimg(rs.getBlob("productimg"));

                book.add(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return book;
    }
	
	
	 public Product getSingleProduct(int id) {
		 Product row = null;
	        try {
	            query = "select * from products where id=? ";

	            pst = this.con.prepareStatement(query);
	            pst.setInt(1, id);
	            ResultSet rs = pst.executeQuery();

	            while (rs.next()) {
	            	row = new Product();
	                row.setId(rs.getInt("id"));
	                row.setProductname(rs.getString("productname"));
	                row.setFeatured(rs.getString("featured"));
	                row.setFlashsale(rs.getString("flashsale"));
	                row.setCategory(rs.getString("category"));
	                row.setDescription(rs.getString("description"));
	                row.setStock(rs.getString("stock"));
	                row.setUnit(rs.getString("unit"));
	                row.setPrice(rs.getInt("price"));
	                row.setProductimg(rs.getBlob("productimg"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            System.out.println(e.getMessage());
	        }

	        return row;
	    }
	
	
	
	
	public double getTotalCartPrice(ArrayList<Cart> cartList) {
        double sum = 0;
        try {
            if (cartList.size() > 0) {
                for (Cart item : cartList) {
                    query = "select price from products where id=?";
                    pst = this.con.prepareStatement(query);
                    pst.setInt(1, item.getId());
                    rs = pst.executeQuery();
                    while (rs.next()) {
                        sum+=rs.getDouble("price")*item.getQuantity();
                    }

                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return sum;
    }

	
	
	   
    public List<Cart> getCartProducts(ArrayList<Cart> cartList) {
        List<Cart> book = new ArrayList<>();
        try {
            if (cartList.size() > 0) {
                for (Cart item : cartList) {
                    query = "select * from products where id=?";
                    pst = this.con.prepareStatement(query);
                    pst.setInt(1, item.getId());
                    rs = pst.executeQuery();
                    while (rs.next()) {
                        Cart row = new Cart();
                        row.setId(rs.getInt("id"));
                        row.setProductname(rs.getString("productname"));
                        row.setCategory(rs.getString("category"));
                        row.setPrice(rs.getInt("price")*item.getQuantity());
                        row.setQuantity(item.getQuantity());
                        book.add(row);
                    }

                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return book;
    }

}